from pymysql import Connection
import streamlit as st
from PIL import Image
from smtplib import SMTP_SSL
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
import json
import requests
from parsel import Selector
from yolo.detect import main, parse_opt
import cv2
import numpy as np
import os
import shutil, tempfile, time
import string, random, time
# -*- coding:utf-8 -*-
from aip import AipImageClassify  # 调用百度api
from streamlit_option_menu import option_menu


# MySQl数据库
conn = Connection(
    host="localhost",
    port=3306,
    user='root',
    password="7012465402",
    autocommit=True,
    charset='utf8',
    database='world'
)
cursor = conn.cursor()

# 百度api

APP_ID = '33049514'
API_KEY = 'Nhi5WtgGKXWc7pygoAxt6G9M'
SECRET_KEY = 'UPkOQ3FrzSS3BC58GzFXDKlniSGtO7qy'
client = AipImageClassify(API_KEY, API_KEY, SECRET_KEY)

# 识别功能
def main_test():
    # 2. horizontal menu
    selected2 = option_menu(None, ["图像检测", "视频检测",],
                            icons=['cloud-upload', 'cloud-upload', "cloud-upload"],
                            menu_icon="cast", default_index=0, orientation="horizontal")
    selected2
    if selected2 == '图像检测':
        st.header('图片检测')
        # 上传图片
        uploaded_file = st.file_uploader("上传一张图片", type="jpg")
        st.write("请您传入jpg格式")
        if uploaded_file is not None:
            # 将传入的文件转为Opencv格式
            file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
            opencv_image = cv2.imdecode(file_bytes, 1)
            # 保存图片
            cv2.imwrite('F:/ground/yolo/data/images/test.jpg', opencv_image)
            # 展示图片
            option = st.selectbox(
                "检测展示",
                ("原图像", "识别图像"))
            if option == "原图像":
                st.image(opencv_image, channels="BGR")
                os.remove('yolo/data/images/test.jpg')
            else:
                opt = parse_opt()
                main(opt)
                image = Image.open("F:/ground/yolo/runs/detect/exp/test.jpg")
                st.image(image)
                shutil.rmtree("F:/ground/yolo/runs/detect/exp")
                f = open("F://ground//count.txt", "r", encoding="UTF-8")
                g = f.read()
                st.header("车辆信息")
                f.close()
                if int(g) <= 2:
                    def get_image(img_path):
                        with open(img_path, 'rb') as fp:
                            return fp.read()

                    image = get_image("yolo/data/images/test.jpg")  # 调用函数
                    # 调用百度api，并打印结果 删除不必要的返回值
                    x = client.carDetect(image, options={"top_num": 1})["result"][0]["name"]
                    st.write(f"您搜索的车辆品牌信息是：{x}")
                else:
                    st.write("请您对准一张车辆，请勿在图片中出现别的车辆。")
                os.remove("F://ground//count.txt")
    elif selected2 == '视频检测':
        st.header("视频检测")
        f = st.file_uploader("上传视频", type="mp4")  # 上传本地视频
        st.write("请您上传MP4格式")
        if f is not None:
            tfile = tempfile.NamedTemporaryFile(delete=False, dir='yolo/data/images')
            tfile.write(f.read())
            tfile.close()
            v = os.rename(f"{tfile.name}", f"F://ground//yolo//data//images//test.mp4")
            opt = parse_opt()
            main(opt)
            progress_text = "加载中请稍后."
            my_bar = st.progress(0, text=progress_text)

            for percent_complete in range(100):
                time.sleep(0.1)
                my_bar.progress(percent_complete + 1, text=progress_text)
            video_file = open(f"F:/ground/yolo/runs/detect/exp/test.mp4", "rb")
            video_bytes = video_file.read()
            st.video(video_bytes)
            video_file.close()
            os.remove('F:/ground/yolo/data/images/test.mp4')
            shutil.rmtree("F:/ground/yolo/runs/detect/exp")
            f = open("F://ground//count.txt", "r", encoding="UTF-8")
            g = f.read()
            if int(g) >= 15:
                st.write(f"当前阶段最大车流量数为:{g}, 车辆拥堵,请安排相关人员前往目的地。")
            else:
                st.write(f"当前阶段最大车流量数为:{g}, 路况通畅")
            f.close()
            os.remove("F://ground//count.txt")


def creat_usertable():
    cursor.execute('create table if not exists car_user(id text, pass text)')

def add_userdata(x,y,z,c):
    if cursor.execute('select * from car_user where id = %s', (x)) and cursor.execute(
            'select * from car_user where name = %s', (z)):
        st.warning("账号或用户名已存在，请更换一个新的账号或用户名")
    else:
        cursor.execute('insert into car_user(id,pass,name,email) values(%s,%s,%s,%s)', (x, y, z, c))
        st.success('恭喜，您已成功注册。')
        st.info('请选择“登录”选项进行登录。')

def login_user(x,y):
    if cursor.execute('select id from car_user where id = %s', (x)):
        cursor.execute('select * from car_user where id = %s and pass = %s', (x, y))
        data = cursor.fetchall()
        return data
    else:
        st.warning('用户不存在，请先选择注册完成。')

def introduce():
    st.header('关于我们')
    st.write('本项目采用用于机器学习、数据可视化的python框架streamlit来搭建Web应用来实现程序设计，数据库采用Redis缓存技术＋MySQl数据库，大大提高用户体验的同时保证了数据的安全性，期间利用爬虫技术来为用户展示所要想查询的车辆，信息最终搭建阿里云上传本地到云服务器实现多用户使用。')
    st.write("车辆识别系统结合yolov5算法等，实现了对车辆的精准识别")
    image = Image.open("C:/Users/Freedom/Desktop/照片/yolo.jpg")
    st.image(image)
    st.subheader("联系方式:")
    st.text(
        '微信: s1570295259  邮箱：1570295259@qq.com '
        '地址：             电话：17325058074'
    )

def zhuxiao():
    if st.button("注销"):
        st.session_state.count = 0
        if st.session_state.count == 0:
            st.snow()
            st.info('注销成功')

# 意见反馈
def feel():
    title_name = st.text_input("姓名：")
    title_age = st.text_input("年龄：")
    title_sex = st.text_input("性别：")
    title_phone = st.text_input("联系方式：")
    title_text = st.text_input("请留下您的宝贵意见：")
    my_list = list()
    if st.button('确认提交'):
        # smtplib模块主要负责发送邮件：是一个发送邮件的动作，连接邮箱服务器，登录邮箱，发送邮件（有发件人，收信人，邮件内容）。
        # email模块主要负责构造邮件：指的是邮箱页面显示的一些构造，如发件人，收件人，主题，正文，附件等。
        my_list.append("姓名：" + title_name)
        my_list.append("年龄：" + title_age)
        my_list.append("性别：" + title_sex)
        my_list.append("联系方式：" + title_phone)
        my_list.append("请留下您的宝贵意见：" + title_text)
        my_str = str(my_list)
        st.write(my_str)
        host_server = 'smtp.qq.com'  #qq邮箱smtp服务器
        sender_qq = '1570295259@qq.com' #发件人邮箱
        pwd = 'zinamhmljshobahc'
        receiver = ['1570295259@qq.com', '1351874428@qq.com' ]#收件人邮箱
        #receiver = '913@qq.com'
        mail_title = '用户反馈' #邮件标题
        mail_content = my_str #邮件正文内容
        # 初始化一个邮件主体
        msg = MIMEMultipart()
        msg["Subject"] = Header(mail_title, 'utf-8')
        msg["From"] = sender_qq
        # msg["To"] = Header("测试邮箱",'utf-8')
        msg['To'] = ";".join(receiver)
        # 邮件正文内容
        msg.attach(MIMEText(mail_content, 'plain','utf-8'))



        smtp = SMTP_SSL(host_server) # ssl登录

        # user:登录邮箱的用户名。
        # password：登录邮箱的密码，
        smtp.login(sender_qq, pwd)
        # sendmail(from_addr,to_addrs,msg,...):
        # from_addr:邮件发送者地址
        # to_addrs:邮件接收者地址。字符串列表['接收地址1','接收地址2','接收地址3',...]或'接收地址'
        # msg：发送消息：邮件内容。msg.as_string():as_string()是将msg(MIMEText对象或者MIMEMultipart对象)变为str。
        smtp.sendmail(sender_qq, receiver, msg.as_string())
        # quit():用于结束SMTP会话。
        smtp.quit()


def myself_information():
    st.subheader("联系方式:")
    st.text(
        '微信: s1570295259  邮箱：1570295259@qq.com '
        '地址：             电话：17325058074'
    )

# 搜索汽车名称url
get_car_id_url = "https://www.dongchedi.com/search?keyword={car_name}&currTab=1&city_name={city_name}&search_mode=history"
# 汽车详情url
get_car_detail_url = "https://www.dongchedi.com/motor/pc/car/series/car_list?series_id={car_id}&city_name={city_name}"
# 车友评论url
get_carfrind_comment = "https://www.dongchedi.com/motor/pc/car/series/get_review_list?series_id={car_id}&sort_by=default&only_owner=0&page=1&count=5"

# headers
headers = {
    'pragma': 'no-cache',
    'accept-language': 'zh-CN,zh;q=0.9',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',
    'accept': '*/*',
    'cache-control': 'no-cache',
    'authority': 'www.dongchedi.com',
    'referer': 'https://www.dongchedi.com/auto/series/run3736',
}

# 获取车辆id的函数，最后返回id
def get_car_id(car_name, city_name):
    carid_url = get_car_id_url.format(car_name=car_name, city_name=city_name)
    response = requests.get(url=carid_url, headers=headers).text
    selector = Selector(text=response)
    car_message = selector.css('''.dcd-car-series a::attr(data-log-click)''').get()
    car_message = json.loads(car_message)
    car_id = car_message.get("car_series_id")
    return car_id

# 获取车友评论
def get_car_frind_comment(car_id):
    car_frind_list = []
    carfrind_url = get_carfrind_comment.format(car_id=car_id)
    response = requests.get(url=carfrind_url, headers=headers).json()
    car_frind_comment_list = response.get("data").get("review_list")
    for car_frind_comment in car_frind_comment_list:
        car_frind_dict = {}
        buy_car_info = car_frind_comment.get("buy_car_info")
        if buy_car_info:
            bought_time = buy_car_info.get("bought_time")
            location = buy_car_info.get("location")
            price = buy_car_info.get("price")
            series_name = buy_car_info.get("series_name")
            car_name = buy_car_info.get("car_name")
            buy_car_info = f'''{bought_time}  {location}  {price} {series_name}-{car_name}'''
        else:
            buy_car_info = ""
        car_content = car_frind_comment.get("content")
        car_frind_dict["车主成交信息"] = buy_car_info
        car_frind_dict["车主评论"] = car_content
        car_frind_list.append(car_frind_dict)
    return car_frind_list

# 获取车辆详情
def get_car_detail(car_id, city_name):
    car_detail = get_car_detail_url.format(car_id=car_id, city_name=city_name)
    response = requests.get(url=car_detail, headers=headers).json()
    online_all_list = response.get("data").get("tab_list")[0].get("data")
    car_type_list = []
    for car_cls in online_all_list:
        car_type_dict = {}
        car_cls = car_cls.get("info")
        if car_cls.get("id"):
            car_name = car_cls.get("series_name")
            car_type = car_cls.get("car_name")
            price = car_cls.get("price")
            owner_price = car_cls.get("owner_price")
            dealer_price = car_cls.get("dealer_price")
            upgrade = car_cls.get("upgrade_text")
            tags = "".join(car_cls.get("tags"))
            if car_cls.get("diff_config_with_no_pic"):
                configure = [i.get('config_group_key')+"-"+i.get('config_key') for i in car_cls.get("diff_config_with_no_pic")]
            else:
                configure = ""
            car_type_dict["车辆名称"] = car_name
            car_type_dict["车辆类型"] = car_type
            car_type_dict["官方指导价"] = price
            car_type_dict["经销商报价"] = dealer_price
            car_type_dict["车主参考价"] = owner_price
            car_type_dict["车辆升级类型"] = upgrade
            car_type_dict["车辆标签"] = tags
            car_type_dict["车辆配置"] = configure
            car_type_list.append(car_type_dict)

    return car_type_list

# 保存为json文件
def save_json(car_name, text):
    json_text = json.dumps(text, ensure_ascii=False)
    with open(car_name+".json", "w", encoding="utf-8") as f:
        f.write(json_text)
        print(car_name+"爬取成功")

# 启动函数
def car_source(car_name, city_name):
    car_id = get_car_id(car_name=car_name, city_name=city_name)
    carinfo = {
        "车辆详细信息": get_car_detail(car_id=car_id, city_name=city_name),
        "车主成交信息": get_car_frind_comment(car_id=car_id)
    }
    save_json(car_name, carinfo)

def car_information():
    st.title("车辆信息搜索")
    title = st.text_input("输入您要查询的车辆信息：")
    title_add = st.text_input("您所在的城市：：")
    if st.button("确认查询"):
        car_source(title, title_add)
        f = open(f"F:/ground/{title}.json", "r", encoding="UTF-8")
        load_dict = json.load(f)
        x = load_dict["车辆详细信息"]
        y = load_dict["车主成交信息"]
        st.header("车辆信息1")
        st.write("车辆名称：" + ' ' + str(x[0]["车辆名称"]))
        st.write('车辆类型:' + ' ' + str(x[0]['车辆类型']))
        st.write("官方指导价:" + ' ' + str(x[0]["官方指导价"]))
        st.write("经销商报价:" + ' ' + str(x[0]["经销商报价"]))
        st.write("车主参考价:" + ' ' + str(x[0]["车主参考价"]))
        st.write("车辆升级类型:" + ' ' + str(x[0]["车辆升级类型"]))
        st.write("车辆升级类型:" + ' ' + str(x[0]["车辆升级类型"]))
        st.write("车辆标签:" + ' ' + str(x[0]["车辆标签"]))
        st.write("车辆配置:" + ' ' + str(x[0]["车辆配置"]))
        st.header("车辆信息2")
        st.write("车辆名称：" + str(x[1]["车辆名称"]))
        st.write('车辆类型:' + str(x[1]['车辆类型']))
        st.write("官方指导价:" + str(x[1]["官方指导价"]))
        st.write("经销商报价:" + str(x[1]["经销商报价"]))
        st.write("车主参考价:" + str(x[1]["车主参考价"]))
        st.write("车辆升级类型:" + str(x[1]["车辆升级类型"]))
        st.write("车辆标签:" + str(x[1]["车辆标签"]))
        st.write("车辆配置:" + str(' '.join(x[1]["车辆配置"])))
        st.header("参考评价")
        st.write("车主成交信息:" + ' ' + str(y[0]["车主成交信息"]))
        st.write("车主评论:" + ' ' + str(y[0]["车主评论"]))
        f.close()

        os.remove(f"F:/ground/{title}.json")
def sounding():
    audio_file = open('Various Artists - The Born Winner.mp3', 'rb')
    audio_bytes = audio_file.read()
    st.audio(audio_bytes, format='audio/ogg')
def mainning():
    st.title("车辆识别系统")
    option = st.selectbox(
        '车辆识别环境背景',
        ('项目背景', '项目意义')
    )


    if option == "项目背景":
        st.header("项目背景")
        image = Image.open("img_pic_1593569058_1.jpg")
        st.image(image)
        st.write("""
              随着智能化的发展，智能家居、智能工厂等智能控制系统已经获得了显著成果。
            智能交通系统与人类生活息息相关，现代的交通堵塞、拥挤等现象屡遭诟病，降低了生产力的发展。
            因此智能交通系统的设计迫在眉睫。深度学习属于机器学习，并经过发展演变为深度神经网络。
            深度学习包括图像识别与卷积网络的构建，在提取图像信息后，通过构建深层的神经网络模拟人脑进行分析，
            可以实现机器获得与人类接近的识别能力，从而在生产生活中得到应用。同时随着大数据时代的到来，
            深度学习在人工智能领域中得到发展，并已在计算机视觉、语音识别及人机博弈等方面取得了良好的效果。
            与此同时，随着社会生产力的发展，轿车已经成为当代人类生活的重要组成。根据中国社科院颁布的2012-2030汽车工业蓝皮书，
            我国已与2012年进去汽车社会，这意味着汽车产业已成为我国经济重要组成部分。
            因此，为有效提高人类的驾驶舒适性及解决汽车发展所引发的交通拥堵及交通事故，智能交通这一概念应运而生。
            智能交通系统中的智能交通工具主要指无人驾驶汽车和汽车辅助驾驶系统。基于深度学习下的车辆目标识别及定位为智能驾驶提供了视觉功能，
            随着GDP的发展以及计算机数据处理能力的提升，图像处理及计算机视觉迅猛发展并成为了智能交通系统的重要组成部分。
            """)
    else:
        st.header("项目意义")
        image = Image.open("R-C.jpg")
        st.image(image)
        st.write("""
            对于人类来说，车辆很容易就识别出来，是因为人类通过学习已经知道车辆长什么样、有哪些特征，如果通过将这些已经掌握的知识教会给计算机会怎么样呢？
            早期，学者就是这样，利用车辆明显的外表特征来检测图像中的车辆。这些外观特征有车辆的对称性、车底阴影等。
            利用晚上车辆尾灯的对称性来确定夜间的车辆目标，这种方法在白天使用效果并不好。邬紫阳利用车辆在道路上行驶底部会存在阴影这一知识来定位车辆可能存在的区域，
            再使用其他后处理方法来检测出车辆。这类直接使用车辆外观特征的检测方法，理解起来直观，
            但是在实际复杂的交通场景中不具备鲁棒性，受天气、光照、道路污损等外界环境的影响，提取特定外观特征时算法阈值的选取会是一个很困难的事，
            如何做到适应各种复杂多变场景的最优阈值是这一类算法性能的关键所在。环境感知模块是自动驾驶系统的重要组成之一,而目标检测和跟踪又是环境感知模块的基础,
            设计出性能优良的目标检测和跟踪模型是自动驾驶领域内的研究重点与难点之一。
            传统的基于人工特征的目标检测算法其泛化能力与鲁棒性较差,因此,利用深度学习技术,以道路交通场景中的行驶车辆为研究对象,
            对目标检测算法进行了研究。主要是基于YOLOV5模型，对车辆进行检测与识别
            """)

Admin = {"username": "admin", "password": "password"}

def user_log():
    st.markdown(
        """
        <style>
        .stApp{
            background-image: url('https://img.zcool.cn/community/019ead5da989b5a801209e1f598699.jpg@1280w_1l_2o_100sh.jpg');
            background-size: cover;
        }
        </style>
        """,
        unsafe_allow_html=True
    )
    tab1, tab2 = st.tabs(['注册', '登录'])
    with tab1:
        x = st.text_input("账户")
        y = st.text_input("密码", type="password")
        left, right = st.columns(2)
        with left:
            z = st.text_input("用户名")
        with right:
            c = st.text_input("邮箱")
        if st.button("提交"):
            add_userdata(x, y, z, c)
    with tab2:
        z = st.text_input("账户.")
        q = st.text_input("密码.", type="password")
        if st.button('登录'):
            loggde_user = login_user(z, q)
            if loggde_user:
                st.session_state.is_authenticated = True
                st.success("登陆成功，欢迎您")
                st.balloons()
            else:
                st.warning('账号或者密码不正确，请检查后再试')


def app_main():
    if not hasattr(st.session_state, 'is_authenticated'):
        st.session_state.is_authenticated = False
    if st.session_state.is_authenticated:

        with st.sidebar:
            st.set_page_config(page_title='车辆识别系统', page_icon=':shark:', layout="centered",
                               initial_sidebar_state="auto",
                               menu_items=None)
            sounding()
            selected3 = option_menu(None,
                                   ["首页", '关于我们', '项目业务', '车辆信息搜索',
                                    '联系我们', '用户反馈', '注销'],
                                   icons=['house'], menu_icon="cast", default_index=1)
            st.markdown(
                """
                <style>
                .stApp{
                    background-image: url('https://img.zcool.cn/community/019ead5da989b5a801209e1f598699.jpg@1280w_1l_2o_100sh.jpg');
                    background-size: cover;
                }
                </style>
                """,
                unsafe_allow_html=True
            )


        if selected3 == '首页':
            mainning()
        elif selected3 == '关于我们':
            introduce()
        elif selected3 == '车辆信息搜索':
            car_information()
        elif selected3 == '项目业务':
            main_test()
        elif selected3 == '联系我们':
            myself_information()
        elif selected3 == '用户反馈':
            feel()
        elif selected3 == '注销':
            if st.button("注销"):
                st.session_state.is_authenticated = False
    else:
        user_log()
if __name__ == '__main__':
    app_main()